#!/bin/sh
rm -rf /usr/local/bin/dvc
