from dvc.testing.workspace_tests import TestLsUrl as _TestLsUrl


class TestLsUrl(_TestLsUrl):
    pass
