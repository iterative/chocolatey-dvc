from setuptools import setup

setup(name="dvc")
